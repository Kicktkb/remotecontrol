package com.example.prueba

data class IrCommand(val code: String)