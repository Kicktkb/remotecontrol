package com.example.prueba

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity

class SplashScreenActivity : AppCompatActivity() {

    private val SPLASH_TIME_OUT: Long = 3000 // Duración de la pantalla de bienvenida en milisegundos

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_screen)

        // Retrasar la apertura de la MainActivity
        Handler().postDelayed({
            // Abrir la MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish() // Cerrar esta actividad para que no se pueda volver atrás desde la MainActivity
        }, SPLASH_TIME_OUT)
    }
}