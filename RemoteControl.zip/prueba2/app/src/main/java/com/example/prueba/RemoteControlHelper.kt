import android.content.Context
import android.hardware.ConsumerIrManager
import android.widget.Toast

class RemoteControlHelper {
    companion object {
        private const val NEC_ADDRESS = 0x00FD
        private const val NEC_POWER_COMMAND = 0xC03F
        private const val NEC_BRIGHTNESS = 0x08F7
        private const val NEC_RESOLUTION = 0x02FD
        private const val NEC_SLEEP = 0x9867
        private const val NEC_MUTE = 0xA857


        fun sendPowerOnCommand(context: Context) {
            sendCommand(context, NEC_POWER_COMMAND)
        }

        fun sendMuteCommand(context: Context) {
            sendCommand(context, NEC_MUTE)
        }

        fun sendBrightnessCommand(context: Context) {
            sendCommand(context, NEC_BRIGHTNESS)
        }

        fun sendResolutionCommand(context: Context) {
            sendCommand(context, NEC_RESOLUTION)
        }

        fun sendSleepCommand(context: Context) {
            sendCommand(context, NEC_SLEEP)
        }


        private fun sendCommand(context: Context, command: Int) {
            val irManager = context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
            try {
                irManager?.let {
                    val pattern = formatNECMessage(NEC_ADDRESS, command)
                    it.transmit(36000, pattern)
                    Toast.makeText(context, "Señal enviada correctamente", Toast.LENGTH_SHORT).show()
                } ?: run {
                    Toast.makeText(context, "Error: ConsumerIrManager no está disponible", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Error al enviar la señal", Toast.LENGTH_SHORT).show()
            }
        }

        private fun formatNECMessage(address: Int, command: Int): IntArray {
            val header = 9000
            val gap = 4500
            val pulse = 560
            val spaceOne = 1690
            val spaceZero = 560
            val stopBit = 560

            val pattern = mutableListOf<Int>()

            fun addBits(bits: Int, size: Int) {
                repeat(size) {
                    pattern.add(pulse)
                    pattern.add(if ((bits shr (size - it - 1)) and 1 == 1) spaceOne else spaceZero)
                }
            }

            pattern.apply {
                add(header)
                add(gap)
                addBits(address, 16)
                addBits(command, 16)
                add(stopBit)
            }

            return pattern.toIntArray()
        }
    }
}
