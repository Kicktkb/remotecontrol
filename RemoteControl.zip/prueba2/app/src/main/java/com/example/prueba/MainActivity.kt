package com.example.prueba

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnPowerToggle).setOnClickListener {
            RemoteControlHelper.sendPowerOnCommand(applicationContext)
        }
        findViewById<Button>(R.id.btnChangeBrightness).setOnClickListener {
            RemoteControlHelper.sendBrightnessCommand(applicationContext)
        }

        findViewById<Button>(R.id.btnChangeResolution).setOnClickListener {
            RemoteControlHelper.sendResolutionCommand(applicationContext)
        }

        findViewById<Button>(R.id.btnProgramShutdown).setOnClickListener {
            RemoteControlHelper.sendSleepCommand(applicationContext)
        }
        findViewById<Button>(R.id.btnMute).setOnClickListener {
            RemoteControlHelper.sendMuteCommand(applicationContext)
        }
    }
}