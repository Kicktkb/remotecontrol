package com.example.prueba

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.core.app.ActivityCompat
import androidx.appcompat.app.AppCompatActivity

class IRPermissionsHelper {
    companion object {
        private const val IR_PERMISSION_REQUEST_CODE = 123

        fun requestIRPermissions(activity: AppCompatActivity) {
            if (ContextCompat.checkSelfPermission(activity, Manifest.permission.TRANSMIT_IR)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    activity,
                    arrayOf(Manifest.permission.TRANSMIT_IR),
                    IR_PERMISSION_REQUEST_CODE
                )
            }
        }
    }
}